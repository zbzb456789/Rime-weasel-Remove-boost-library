﻿--=========================================================
-- 版本检测
--=========================================================

function version_translator(input, seg)
  if input == "lua" then
    local version_str = "Lua版本：" .. _VERSION
    local api_status = (rime_api ~= nil) and "API正常" or "API缺失"
    local cand = Candidate("version", seg.start, seg._end,
      version_str, " ["..api_status.."]")
    yield(cand)
  end
end

